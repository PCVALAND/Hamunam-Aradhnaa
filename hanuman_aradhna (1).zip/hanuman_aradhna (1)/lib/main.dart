
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:intl/intl.dart';
import 'dart:async';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService().init();
  runApp(HanumanAradhnaApp());
}

class HanumanAradhnaApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Hanuman Aradhna',
      theme: ThemeData(
        primarySwatch: Colors.deepOrange,
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final Uri _apkUrl = Uri.parse(
      'https://drive.google.com/file/d/1NcRZDNbVRdItGyCKbVtVWug0b6I3qIp9/view');
  final TextEditingController dateController = TextEditingController();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController houseNoController = TextEditingController();
  final TextEditingController youtubeController = TextEditingController();

  List<Map<String, String>> events = [];

  Future<void> _launchURL() async {
    if (!await launchUrl(_apkUrl, mode: LaunchMode.externalApplication)) {
      throw 'Could not launch $_apkUrl';
    }
  }

  void _scheduleBirthdayNotification() {
    final now = DateTime.now();
    final birthdayTime = DateTime(now.year, now.month, now.day, 0, 0);
    NotificationService().showScheduledNotification(
      title: '🎂 Happy Birthday!',
      body: 'Valand Priyank ki taraf se hardik shubhkamnayein!',
      scheduledTime: birthdayTime.add(Duration(seconds: 5)),
    );
  }

  void _scanBluetoothDevices() async {
    await Permission.bluetooth.request();
    FlutterBluePlus.startScan(timeout: Duration(seconds: 4));
    FlutterBluePlus.scanResults.listen((results) {
      for (ScanResult r in results) {
        print('Found device: ${r.device.name}');
      }
    });
  }

  void _addEvent() {
    if (dateController.text.isNotEmpty &&
        nameController.text.isNotEmpty &&
        houseNoController.text.isNotEmpty) {
      setState(() {
        events.add({
          'date': dateController.text,
          'name': nameController.text,
          'house': houseNoController.text
        });
      });
      dateController.clear();
      nameController.clear();
      houseNoController.clear();
    }
  }

  void _openYouTubeLink() async {
    final url = youtubeController.text;
    if (url.isNotEmpty && await canLaunchUrl(Uri.parse(url))) {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('🚩 Hanuman Aradhna'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ElevatedButton(
              onPressed: _launchURL,
              child: const Text('📥 Download App'),
            ),
            ElevatedButton(
              onPressed: _scheduleBirthdayNotification,
              child: const Text('🎉 Schedule Birthday Notification'),
            ),
            ElevatedButton(
              onPressed: _scanBluetoothDevices,
              child: const Text('🔍 Scan Bluetooth Devices'),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: youtubeController,
              decoration: const InputDecoration(labelText: 'YouTube Bhajan Link'),
            ),
            ElevatedButton(
              onPressed: _openYouTubeLink,
              child: const Text('🎵 Open Bhajan'),
            ),
            const Divider(),
            Text('📅 Add Prasadi Calendar Entry'),
            TextField(
              controller: dateController,
              decoration: const InputDecoration(labelText: 'Date (DD-MM-YYYY)'),
            ),
            TextField(
              controller: nameController,
              decoration: const InputDecoration(labelText: 'Name'),
            ),
            TextField(
              controller: houseNoController,
              decoration: const InputDecoration(labelText: 'House No'),
            ),
            ElevatedButton(
              onPressed: _addEvent,
              child: const Text('➕ Add Entry'),
            ),
            const Divider(),
            ...events.map((e) => ListTile(
                  title: Text('${e['name']} (House: ${e['house']})'),
                  subtitle: Text('Date: ${e['date']}'),
                )),
            const SizedBox(height: 20),
            const Text(
              '© Valand Priyank',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}

class NotificationService {
  static final _notifications = FlutterLocalNotificationsPlugin();

  Future<void> init() async {
    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const InitializationSettings initializationSettings =
        InitializationSettings(android: initializationSettingsAndroid);

    await _notifications.initialize(initializationSettings);
  }

  Future<void> showScheduledNotification({
    required String title,
    required String body,
    required DateTime scheduledTime,
  }) async {
    await _notifications.zonedSchedule(
      0,
      title,
      body,
      scheduledTime.toLocal(),
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'birthday_channel_id',
          'Birthday Notifications',
          importance: Importance.high,
          priority: Priority.high,
        ),
      ),
      androidAllowWhileIdle: true,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }
}
<link rel="manifest" href="manifest.json">